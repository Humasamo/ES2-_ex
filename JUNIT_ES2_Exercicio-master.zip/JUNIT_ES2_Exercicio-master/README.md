# ESII_Exercicio BinString - JUNIT
